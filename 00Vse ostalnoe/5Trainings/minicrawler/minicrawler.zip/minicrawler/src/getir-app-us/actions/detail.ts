import Product from "../../interfaces/product";

export default function detail(productid: string): Product {
  // TODO

  return { id: "0", name: "placeholder" };
}