import Product from "../../interfaces/product";

export default function search(productid: string): Product[] {
  // TODO
  return [];
}