import search from "./actions/search";
import detail from "./actions/detail";

export default {
  search,
  detail
}